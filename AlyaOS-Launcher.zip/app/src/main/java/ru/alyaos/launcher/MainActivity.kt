package ru.alyaos.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import kotlin.random.Random

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

data class AppEntry(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var bubble: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var grid: GridView

    private val adapter = AppAdapter()
    private var current: Phrase? = null
    private var apps: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else dp(24)

        root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0B1530"), Color.parseColor("#22427A"), Color.parseColor("#7F9ACB"))
        )

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), sb + dp(28), dp(20), dp(20))
        }
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        content.addView(TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 64f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        content.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"
            format12Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(Color.parseColor("#DDFFFFFF"))
        })

        content.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        val avatar = buildAvatar()
        avatar.setOnClickListener { nextPhrase() }
        content.addView(avatar, LinearLayout.LayoutParams(dp(112), dp(112)))

        content.addView(TextView(this).apply {
            text = "Аля"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })

        bubble = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.parseColor("#14213D"))
            background = rounded(Color.parseColor("#EEFFFFFF"), 22)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setOnClickListener { nextPhrase() }
            setOnLongClickListener {
                current?.let { p ->
                    text = "💭 " + p.subtext
                    setTypeface(null, Typeface.ITALIC)
                }
                true
            }
        }
        content.addView(bubble, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        content.addView(TextView(this).apply {
            text = "Нажми: другая фраза · Удерживай: что она имела в виду"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#CCFFFFFF"))
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })

        content.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        content.addView(buildDock(), LinearLayout.LayoutParams(WRAP, WRAP))

        content.addView(TextView(this).apply {
            text = "Все приложения  ⌃"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(Color.parseColor("#44FFFFFF"), 20)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setOnClickListener { openDrawer() }
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(14) })

        buildDrawer(sb)
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -900f && Math.abs(vy) > Math.abs(vx)) {
                    openDrawer()
                    return true
                }
                return false
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }

        setContentView(root)
        current = Phrases.random(hourNow(), null)
        bubble.text = current?.text
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        // Аля кокетничает не всегда: новая фраза примерно в 60% возвратов на рабочий стол
        if (Random.nextInt(100) < 60) nextPhrase()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeDrawer()
    }

    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
        // на рабочем столе «Назад» ничего не делает
    }

    // ---------- UI ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun hourNow(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun nextPhrase() {
        current = Phrases.random(hourNow(), current)
        bubble.text = current?.text
        bubble.setTypeface(null, Typeface.NORMAL)
    }

    /** Если положить свой арт в app/src/main/res/drawable-nodpi/alya.png, он станет аватаром. */
    private fun buildAvatar(): View {
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E8EEF9"))
            setStroke(dp(3), Color.parseColor("#6FA3FF"))
        }
        val resId = resources.getIdentifier("alya", "drawable", packageName)
        return if (resId != 0) {
            ImageView(this).apply {
                setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = ring
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
            }
        } else {
            TextView(this).apply {
                text = "А"
                textSize = 52f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#22427A"))
                gravity = Gravity.CENTER
                background = ring
            }
        }
    }

    private fun buildDock(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#33FFFFFF"), 28)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://www.example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (i in intents) {
            val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            row.addView(ImageView(this).apply {
                setImageDrawable(ri.loadIcon(packageManager))
                setOnClickListener { startSafe(i) }
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                marginStart = dp(8)
                marginEnd = dp(8)
            })
        }
        return row
    }

    private fun buildDrawer(statusBar: Int) {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F20B1530"))
            setPadding(dp(12), statusBar + dp(12), dp(12), dp(12))
            visibility = View.GONE
            isClickable = true
        }
        search = EditText(this).apply {
            hint = "Поиск приложений"
            setHintTextColor(Color.parseColor("#99FFFFFF"))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = rounded(Color.parseColor("#22FFFFFF"), 20)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    applyFilter(s?.toString() ?: "")
                }
            })
        }
        drawer.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))

        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(14)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setSelector(ColorDrawable(Color.TRANSPARENT))
            setPadding(0, dp(14), 0, 0)
            clipToPadding = false
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                startSafe(shown[pos].intent)
                closeDrawer()
            }
            setOnItemLongClickListener { _, _, pos, _ ->
                startSafe(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + shown[pos].pkg))
                )
                closeDrawer()
                true
            }
        }
        drawer.addView(grid, LinearLayout.LayoutParams(MATCH, MATCH))
    }

    private fun openDrawer() {
        search.setText("")
        drawer.visibility = View.VISIBLE
    }

    private fun closeDrawer() {
        if (!::drawer.isInitialized) return
        drawer.visibility = View.GONE
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(drawer.windowToken, 0)
    }

    // ---------- Apps ----------

    private fun loadApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppEntry(
                    it.loadLabel(packageManager).toString(),
                    it.activityInfo.packageName,
                    it.loadIcon(packageManager),
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            .sortedBy { it.label.lowercase() }
        applyFilter(search.text.toString())
    }

    private fun applyFilter(query: String) {
        val q = query.trim().lowercase()
        shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
    }

    private fun startSafe(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Не получилось открыть", Toast.LENGTH_SHORT).show()
        }
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = shown[position]
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(4), dp(2), dp(4))
                addView(ImageView(this@MainActivity), LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(TextView(this@MainActivity).apply {
                    textSize = 11f
                    setTextColor(Color.WHITE)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
            }
            (cell.getChildAt(0) as ImageView).setImageDrawable(app.icon)
            (cell.getChildAt(1) as TextView).text = app.label
            return cell
        }
    }
}
